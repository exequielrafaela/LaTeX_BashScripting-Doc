#!/bin/bash

#Leer y tratar de predecir que es lo que hace este script
#Probar y determinar que es lo que hace este script

echo "i in hola 1 * 2 adios"
for i in hola 1 * 2 adios
do
echo "Iterando ... i tiene el valor $i"
done

echo "for i in hola 1 \* 2 adios"
for i in hola 1 \* 2 adios
do
echo "Iterando ... i tiene el valor $i"
done