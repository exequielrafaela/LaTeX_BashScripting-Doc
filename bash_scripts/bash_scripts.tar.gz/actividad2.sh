#!/bin/bash

#Realizar un script que, dado un número, indique si es o no divisible por 2.
#Si no se ingresa un número debe decir como usar el programa.

divisor=2

read -t 3 -p "Input a Number to check if it's divisible by 2 : " Number || echo -e "\nPlase enter a number during the 1st 3 secs"
#echo $(($Number / $divisor)) 
#expr $Number / $divisor  
#if [$(($number % 5)) -eq 0 ]

# Use the && (and) and || (or) operators:
#if [[ expression ]] && [[ expression ]] || [[ expression ]] ; then

#They can also be used within a single [[ ]]:
#if [[ expression && expression || expression ]] ; then

#And, finally, you can group them to ensure order of evaluation:
#if [[ expression && ( expression || expression ) ]] ; then

if [[ "$Number" -ne 0 ]] && [[ -n $Number ]]
then
	if (($Number % $divisor == 0))
	then
    echo "Your number is divisible by 2"
	else
    echo "Your number is not divisible by 2"
	fi
else
	echo "You must enter a number dif from 0 (cero) to check if it's divisible by 2"
fi