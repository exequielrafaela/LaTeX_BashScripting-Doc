#!/bin/bash

if test -d /var
then
	echo "El dir exsite"
else
	echo "el dir no existe"
fi
