#!bin/bash

#Haciendo uso del comando sed elimine todas las lineas del archivo que
#comiencen con #  (comentarios).

#Mi primer programa

mi # mi

echo "Hola Mundo"